# Pens
各种笔型的算法实现：包括原笔迹钢笔的手写和毛笔的手写

效果图展示如下：

![image](https://github.com/doubledouble123/Pens/blob/master/%E6%95%88%E6%9E%9C%E5%9B%BE/show_pen.png)

![image](https://github.com/doubledouble123/Pens/blob/master/%E6%95%88%E6%9E%9C%E5%9B%BE/show_brush.png)
